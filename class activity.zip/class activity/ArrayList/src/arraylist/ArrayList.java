/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraylist;

//import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Map.Entry;

/**
 *
 * @author macstudent
 */
public class ArrayList {

    /**
     * @param args the command line arguments
     */
    
    public static Integer n;
    public static String h; 
    public static void main(String[] args) {
        // TODO code application logic here
        // creating Hashmap 
        HashMap<String, Integer> newMap = new HashMap<String, Integer>();
        
        Scanner in = new Scanner(System.in);
        for(int i=0;i<3;i++)
        {
           System.out.println("Enter String : ");
          n = in.nextInt();
        System.out.println("Enter value : ");
          h = in.next(); 
          
          
            
        }
        
        
        
        
        
      }
    
}
